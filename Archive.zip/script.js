var url = window.location;
url = url.toString();
url = url.replace('.com','.com.');
window.location.replace(url);
